package otherway;

public interface TemperatureConverter {
    double convertFahrenheitToCelsius(double tempInF);

    double convertCelsiusToFahrenheit(double tempInC);
}